# RSA-Factoring-Challenge

./factors <file>

./rsa <file>
